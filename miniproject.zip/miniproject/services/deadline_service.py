from datetime import date, datetime

class DeadlineService:
    @staticmethod
    def parse_date(date_str):
        if not date_str:
            return None
        if isinstance(date_str, (date, datetime)):
            return date_str if isinstance(date_str, date) else date_str.date()
        try:
            return datetime.strptime(str(date_str).strip(), "%Y-%m-%d").date()
        except ValueError:
            return None

    @classmethod
    def analyze_deadline(cls, deadline_val):
        """
        Analyzes a deadline and returns status classification, days remaining,
        and UI badge styling classes.
        """
        d = cls.parse_date(deadline_val)
        if not d:
            return {
                'days_remaining': None,
                'status': 'no_deadline',
                'label': 'Flexible',
                'badge_class': 'badge-soft-secondary',
                'alert_level': 'none',
                'formatted': 'Not specified'
            }

        today = date.today()
        days = (d - today).days

        formatted = d.strftime("%b %d, %Y")

        if days < 0:
            return {
                'days_remaining': days,
                'status': 'overdue',
                'label': f'Overdue by {abs(days)}d',
                'badge_class': 'badge-soft-danger',
                'alert_level': 'danger',
                'formatted': formatted
            }
        elif days == 0:
            return {
                'days_remaining': 0,
                'status': 'due_today',
                'label': 'Due Today!',
                'badge_class': 'badge-soft-danger animate-pulse',
                'alert_level': 'danger',
                'formatted': formatted
            }
        elif days <= 3:
            return {
                'days_remaining': days,
                'status': 'urgent',
                'label': f'{days} day{"s" if days > 1 else ""} left',
                'badge_class': 'badge-soft-warning',
                'alert_level': 'warning',
                'formatted': formatted
            }
        elif days <= 7:
            return {
                'days_remaining': days,
                'status': 'approaching',
                'label': f'{days} days left',
                'badge_class': 'badge-soft-info',
                'alert_level': 'info',
                'formatted': formatted
            }
        else:
            return {
                'days_remaining': days,
                'status': 'upcoming',
                'label': f'{days} days left',
                'badge_class': 'badge-soft-success',
                'alert_level': 'normal',
                'formatted': formatted
            }

    @classmethod
    def get_upcoming_deadlines_for_user(cls, applications, limit=5):
        """
        Takes user applications, filters for upcoming/urgent deadlines,
        sorts by urgency.
        """
        tracked = []
        for app in applications:
            target_date = app.get('interview_date') or app.get('deadline')
            if target_date:
                analysis = cls.analyze_deadline(target_date)
                is_interview = bool(app.get('interview_date'))
                tracked.append({
                    'app': app,
                    'is_interview': is_interview,
                    'event_type': 'Interview' if is_interview else 'Application Deadline',
                    'date': target_date,
                    'analysis': analysis
                })

        # Sort: urgent and upcoming first (days >= 0 ascending), then overdue
        tracked.sort(key=lambda x: (
            0 if x['analysis']['status'] in ('due_today', 'urgent') else
            1 if x['analysis']['status'] in ('approaching', 'upcoming') else 2,
            x['analysis']['days_remaining'] if x['analysis']['days_remaining'] is not None else 999
        ))

        return tracked[:limit]

