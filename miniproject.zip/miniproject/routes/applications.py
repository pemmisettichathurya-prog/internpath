from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from routes.auth import login_required
from models.application import ApplicationModel
from models.internship import InternshipModel
from models.notification import NotificationModel
from services.deadline_service import DeadlineService

applications_bp = Blueprint('applications', __name__)

@applications_bp.route('/applications')
@login_required
def index():
    user_id = session['user_id']
    view_mode = request.args.get('view', 'kanban') # 'kanban' or 'table'
    status_filter = request.args.get('status', 'all')

    apps = ApplicationModel.get_by_user(user_id)

    # Enrich each application with deadline analysis & status styling
    enriched_apps = []
    for app in apps:
        app_copy = dict(app)
        app_copy['applied_analysis'] = DeadlineService.analyze_deadline(app['applied_date'])
        if app.get('interview_date'):
            app_copy['interview_analysis'] = DeadlineService.analyze_deadline(app['interview_date'])
        if app.get('deadline'):
            app_copy['deadline_analysis'] = DeadlineService.analyze_deadline(app['deadline'])
        enriched_apps.append(app_copy)

    # Group into kanban columns
    kanban_columns = {
        'Applied': [],
        'Under Review': [],
        'Shortlisted': [],
        'Interview Scheduled': [],
        'Selected': [],
        'Rejected': []
    }

    for app in enriched_apps:
        status = app['status']
        if status in kanban_columns:
            kanban_columns[status].append(app)
        else:
            kanban_columns['Applied'].append(app)

    # Stats summary
    stats = ApplicationModel.get_user_stats(user_id)

    return render_template(
        'applications/index.html',
        applications=enriched_apps,
        kanban_columns=kanban_columns,
        view_mode=view_mode,
        stats=stats,
        statuses=ApplicationModel.STATUSES,
        today_date=str(date.today())
    )

@applications_bp.route('/applications/add', methods=['POST'])
@login_required
def add():
    user_id = session['user_id']

    company_name = request.form.get('company_name', '').strip()
    role_title = request.form.get('role_title', '').strip()
    domain = request.form.get('domain', '').strip()
    status = request.form.get('status', 'Applied').strip()
    applied_date = request.form.get('applied_date', str(date.today())).strip()
    interview_date = request.form.get('interview_date', '').strip() or None
    deadline = request.form.get('deadline', '').strip() or None
    application_url = request.form.get('application_url', '').strip()
    stipend = request.form.get('stipend', '').strip()
    location = request.form.get('location', '').strip()
    notes = request.form.get('notes', '').strip()
    internship_id = request.form.get('internship_id')
    internship_id = int(internship_id) if internship_id and internship_id.isdigit() else None

    if not company_name or not role_title:
        flash("Company name and role title are required.", "danger")
        return redirect(request.referrer or url_for('applications.index'))

    app_id = ApplicationModel.create(
        user_id=user_id,
        company_name=company_name,
        role_title=role_title,
        domain=domain,
        status=status,
        applied_date=applied_date,
        interview_date=interview_date,
        deadline=deadline,
        application_url=application_url,
        stipend=stipend,
        location=location,
        notes=notes,
        internship_id=internship_id
    )

    # Create notification if interview is scheduled
    if interview_date:
        NotificationModel.create(
            user_id=user_id,
            title=f"Interview Added: {company_name}",
            message=f"Interview for {role_title} on {interview_date}.",
            type="interview",
            link="/applications"
        )

    flash(f"Application for '{role_title}' at {company_name} added to your tracker!", "success")
    return redirect(url_for('applications.index'))

@applications_bp.route('/applications/<int:id>/update', methods=['POST'])
@login_required
def update(id):
    user_id = session['user_id']
    existing = ApplicationModel.get_by_id(id, user_id)
    if not existing:
        flash("Application not found.", "danger")
        return redirect(url_for('applications.index'))

    company_name = request.form.get('company_name', '').strip()
    role_title = request.form.get('role_title', '').strip()
    domain = request.form.get('domain', '').strip()
    status = request.form.get('status', existing['status']).strip()
    applied_date = request.form.get('applied_date', existing['applied_date']).strip()
    interview_date = request.form.get('interview_date', '').strip() or None
    deadline = request.form.get('deadline', '').strip() or None
    application_url = request.form.get('application_url', '').strip()
    stipend = request.form.get('stipend', '').strip()
    location = request.form.get('location', '').strip()
    notes = request.form.get('notes', '').strip()

    ApplicationModel.update(
        application_id=id,
        user_id=user_id,
        company_name=company_name,
        role_title=role_title,
        domain=domain,
        status=status,
        applied_date=applied_date,
        interview_date=interview_date,
        deadline=deadline,
        application_url=application_url,
        stipend=stipend,
        location=location,
        notes=notes
    )

    # If status changed to Selected or Interview Scheduled, trigger notification
    if status != existing['status']:
        if status == 'Interview Scheduled':
            NotificationModel.create(
                user_id=user_id,
                title=f"Interview Scheduled: {company_name}",
                message=f"Your application status for {role_title} is now Interview Scheduled!",
                type="interview",
                link="/applications"
            )
        elif status == 'Selected':
            NotificationModel.create(
                user_id=user_id,
                title=f"🎉 Offer Received: {company_name}!",
                message=f"Congratulations! You were marked Selected for {role_title}!",
                type="status",
                link="/applications"
            )

    flash("Application details updated successfully.", "success")
    return redirect(url_for('applications.index'))

@applications_bp.route('/applications/<int:id>/status', methods=['POST'])
@login_required
def update_status(id):
    user_id = session['user_id']
    
    # Can receive JSON (drag-and-drop) or Form POST
    if request.is_json:
        data = request.get_json()
        new_status = data.get('status')
    else:
        new_status = request.form.get('status')

    if not new_status:
        if request.is_json:
            return jsonify({'success': False, 'message': 'Missing status'}), 400
        flash("Status is required.", "danger")
        return redirect(url_for('applications.index'))

    success = ApplicationModel.update_status(id, user_id, new_status)
    if not success:
        if request.is_json:
            return jsonify({'success': False, 'message': 'Invalid status'}), 400
        flash("Could not update status.", "danger")
        return redirect(url_for('applications.index'))

    if request.is_json:
        return jsonify({'success': True, 'new_status': new_status, 'message': f'Status changed to {new_status}'})

    flash(f"Status updated to '{new_status}'!", "success")
    return redirect(url_for('applications.index'))

@applications_bp.route('/applications/<int:id>/delete', methods=['POST'])
@login_required
def delete(id):
    user_id = session['user_id']
    ApplicationModel.delete(id, user_id)
    flash("Application successfully removed from tracker.", "info")
    return redirect(url_for('applications.index'))

