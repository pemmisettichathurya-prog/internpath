from database.db import query_db, execute_db
from werkzeug.security import generate_password_hash, check_password_hash

class UserModel:
    @staticmethod
    def get_by_id(user_id):
        return query_db("SELECT * FROM users WHERE id = ?", (user_id,), one=True)

    @staticmethod
    def get_by_email(email):
        return query_db("SELECT * FROM users WHERE LOWER(email) = LOWER(?)", (email.strip(),), one=True)

    @staticmethod
    def create(full_name, email, password, college_name="", degree="", branch="", graduation_year=None, skills="", preferred_domain="", preferred_location=""):
        password_hash = generate_password_hash(password)
        query = """
            INSERT INTO users (full_name, email, password_hash, role, college_name, degree, branch, graduation_year, skills, preferred_domain, preferred_location)
            VALUES (?, ?, ?, 'student', ?, ?, ?, ?, ?, ?, ?)
        """
        user_id = execute_db(query, (
            full_name.strip(),
            email.strip().lower(),
            password_hash,
            college_name.strip() if college_name else "",
            degree.strip() if degree else "",
            branch.strip() if branch else "",
            graduation_year if graduation_year else None,
            skills.strip() if skills else "",
            preferred_domain.strip() if preferred_domain else "",
            preferred_location.strip() if preferred_location else ""
        ))
        return user_id

    @staticmethod
    def verify_password(stored_hash, password):
        return check_password_hash(stored_hash, password)

    @staticmethod
    def update_profile(user_id, full_name, college_name, degree, branch, graduation_year, skills, preferred_domain, preferred_location, portfolio_url, linkedin_url, github_url):
        query = """
            UPDATE users 
            SET full_name = ?, college_name = ?, degree = ?, branch = ?, graduation_year = ?, 
                skills = ?, preferred_domain = ?, preferred_location = ?, portfolio_url = ?, 
                linkedin_url = ?, github_url = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """
        execute_db(query, (
            full_name.strip(),
            college_name.strip(),
            degree.strip(),
            branch.strip(),
            graduation_year if graduation_year else None,
            skills.strip(),
            preferred_domain.strip(),
            preferred_location.strip(),
            portfolio_url.strip(),
            linkedin_url.strip(),
            github_url.strip(),
            user_id
        ))

    @staticmethod
    def update_resume(user_id, filename):
        query = "UPDATE users SET resume_filename = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
        execute_db(query, (filename, user_id))

    @staticmethod
    def get_all_students():
        query = """
            SELECT u.*, 
                   (SELECT COUNT(*) FROM applications a WHERE a.user_id = u.id) as total_applications,
                   (SELECT COUNT(*) FROM saved_internships s WHERE s.user_id = u.id) as total_saved
            FROM users u
            WHERE u.role = 'student'
            ORDER BY u.created_at DESC
        """
        return query_db(query)

