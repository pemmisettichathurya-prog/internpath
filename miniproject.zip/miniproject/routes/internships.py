from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from routes.auth import login_required
from models.user import UserModel
from models.internship import InternshipModel
from models.application import ApplicationModel
from services.recommendation import RecommendationEngine
from services.deadline_service import DeadlineService

internships_bp = Blueprint('internships', __name__)

@internships_bp.route('/internships')
def index():
    search = request.args.get('search', '').strip()
    domain = request.args.get('domain', '').strip()
    location = request.args.get('location', '').strip()
    work_mode = request.args.get('work_mode', '').strip()
    stipend_type = request.args.get('stipend_type', '').strip()
    min_stipend = request.args.get('min_stipend', '').strip()
    skill = request.args.get('skill', '').strip()
    sort_by = request.args.get('sort_by', 'deadline_asc').strip()

    # Get filtered internships from DB
    internships = InternshipModel.filter_internships(
        search=search,
        domain=domain,
        location=location,
        work_mode=work_mode,
        stipend_type=stipend_type,
        min_stipend=min_stipend,
        skill=skill,
        sort_by=sort_by
    )

    # Context data for filters
    all_domains = [
        "Artificial Intelligence",
        "Machine Learning",
        "Python Development",
        "Data Science",
        "Web Development",
        "Java Development",
        "Cloud Computing",
        "Cybersecurity",
        "Digital Marketing",
        "UI/UX Design"
    ]
    all_locations = InternshipModel.get_locations()

    user_id = session.get('user_id')
    student = None
    saved_ids = set()
    applied_ids = set()

    if user_id:
        student = UserModel.get_by_id(user_id)
        saved_ids = InternshipModel.get_saved_ids(user_id)
        user_apps = ApplicationModel.get_by_user(user_id)
        applied_ids = {a['internship_id'] for a in user_apps if a['internship_id']}

    # Enrich listings with match data & deadline analysis
    enhanced_list = []
    for item in internships:
        item_copy = dict(item)
        item_copy['is_saved'] = item['id'] in saved_ids
        item_copy['is_applied'] = item['id'] in applied_ids
        item_copy['deadline_info'] = DeadlineService.analyze_deadline(item['deadline'])
        
        if student and session.get('role') == 'student':
            item_copy['match'] = RecommendationEngine.calculate_match(student, item)
        else:
            item_copy['match'] = None

        enhanced_list.append(item_copy)

    # Sort by match percentage if selected
    if sort_by == 'match_desc' and student:
        enhanced_list.sort(key=lambda x: x['match']['percentage'] if x['match'] else 0, reverse=True)

    return render_template(
        'internships/index.html',
        internships=enhanced_list,
        total_results=len(enhanced_list),
        domains=all_domains,
        locations=all_locations,
        filters={
            'search': search,
            'domain': domain,
            'location': location,
            'work_mode': work_mode,
            'stipend_type': stipend_type,
            'min_stipend': min_stipend,
            'skill': skill,
            'sort_by': sort_by
        }
    )

@internships_bp.route('/internships/<int:id>')
def detail(id):
    internship = InternshipModel.get_by_id(id)
    if not internship:
        flash("Internship not found.", "danger")
        return redirect(url_for('internships.index'))

    user_id = session.get('user_id')
    student = None
    is_saved = False
    is_applied = False
    match_data = None

    if user_id:
        student = UserModel.get_by_id(user_id)
        is_saved = InternshipModel.is_saved(user_id, id)
        user_apps = ApplicationModel.get_by_user(user_id)
        is_applied = any(a['internship_id'] == id for a in user_apps)

        if student and session.get('role') == 'student':
            match_data = RecommendationEngine.calculate_match(student, internship)

    deadline_info = DeadlineService.analyze_deadline(internship['deadline'])

    # Similar internships in same domain
    similar = InternshipModel.filter_internships(domain=internship['domain'])
    similar = [s for s in similar if s['id'] != id][:3]
    for s in similar:
        s_deadline = DeadlineService.analyze_deadline(s['deadline'])
        s['deadline_info'] = s_deadline

    # Split skills for badge display
    skills_list = [s.strip() for s in internship['required_skills'].split(',') if s.strip()]

    return render_template(
        'internships/detail.html',
        internship=internship,
        skills_list=skills_list,
        deadline_info=deadline_info,
        match_data=match_data,
        is_saved=is_saved,
        is_applied=is_applied,
        similar_internships=similar,
        today_date=str(date.today())
    )

@internships_bp.route('/internships/<int:id>/save', methods=['POST'])
@login_required
def toggle_save(id):
    user_id = session['user_id']
    is_currently_saved = InternshipModel.is_saved(user_id, id)

    if is_currently_saved:
        InternshipModel.unsave_internship(user_id, id)
        status = 'unsaved'
        message = 'Internship removed from saved favourites.'
    else:
        InternshipModel.save_internship(user_id, id)
        status = 'saved'
        message = 'Internship added to your saved favourites!'

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
        return jsonify({'status': status, 'message': message, 'is_saved': (status == 'saved')})

    flash(message, 'info' if status == 'unsaved' else 'success')
    return redirect(request.referrer or url_for('internships.index'))

@internships_bp.route('/internships/saved')
@login_required
def saved():
    user_id = session['user_id']
    student = UserModel.get_by_id(user_id)
    saved_list = InternshipModel.get_saved_internships(user_id)

    enhanced_saved = []
    for item in saved_list:
        item_copy = dict(item)
        item_copy['deadline_info'] = DeadlineService.analyze_deadline(item['deadline'])
        if student:
            item_copy['match'] = RecommendationEngine.calculate_match(student, item)
        enhanced_saved.append(item_copy)

    return render_template('internships/saved.html', saved_internships=enhanced_saved)

