from database.db import query_db, execute_db

class ApplicationModel:
    STATUSES = ['Applied', 'Under Review', 'Shortlisted', 'Interview Scheduled', 'Selected', 'Rejected']

    @staticmethod
    def get_by_id(application_id, user_id=None):
        if user_id:
            return query_db("SELECT * FROM applications WHERE id = ? AND user_id = ?", (application_id, user_id), one=True)
        return query_db("SELECT * FROM applications WHERE id = ?", (application_id,), one=True)

    @staticmethod
    def get_by_user(user_id, status=None):
        if status:
            return query_db("SELECT * FROM applications WHERE user_id = ? AND status = ? ORDER BY applied_date DESC", (user_id, status))
        return query_db("SELECT * FROM applications WHERE user_id = ? ORDER BY applied_date DESC", (user_id,))

    @staticmethod
    def create(user_id, company_name, role_title, domain="", status="Applied", applied_date=None, interview_date=None, deadline=None, application_url="", stipend="", location="", notes="", internship_id=None):
        query = """
            INSERT INTO applications 
            (user_id, internship_id, company_name, role_title, domain, status, applied_date, interview_date, deadline, application_url, stipend, location, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        return execute_db(query, (
            user_id, internship_id, company_name.strip(), role_title.strip(), domain.strip() if domain else "",
            status, applied_date, interview_date if interview_date else None, deadline if deadline else None,
            application_url.strip() if application_url else "", stipend.strip() if stipend else "",
            location.strip() if location else "", notes.strip() if notes else ""
        ))

    @staticmethod
    def update(application_id, user_id, company_name, role_title, domain, status, applied_date, interview_date, deadline, application_url, stipend, location, notes):
        query = """
            UPDATE applications 
            SET company_name = ?, role_title = ?, domain = ?, status = ?, applied_date = ?, 
                interview_date = ?, deadline = ?, application_url = ?, stipend = ?, 
                location = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ? AND user_id = ?
        """
        execute_db(query, (
            company_name.strip(), role_title.strip(), domain.strip() if domain else "", status,
            applied_date, interview_date if interview_date else None, deadline if deadline else None,
            application_url.strip() if application_url else "", stipend.strip() if stipend else "",
            location.strip() if location else "", notes.strip() if notes else "",
            application_id, user_id
        ))

    @staticmethod
    def update_status(application_id, user_id, new_status):
        if new_status not in ApplicationModel.STATUSES:
            return False
        query = "UPDATE applications SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?"
        execute_db(query, (new_status, application_id, user_id))
        return True

    @staticmethod
    def delete(application_id, user_id):
        execute_db("DELETE FROM applications WHERE id = ? AND user_id = ?", (application_id, user_id))

    @staticmethod
    def get_user_stats(user_id):
        apps = query_db("SELECT status, count(*) as count FROM applications WHERE user_id = ? GROUP BY status", (user_id,))
        counts = {s: 0 for s in ApplicationModel.STATUSES}
        total = 0
        for row in apps:
            if row['status'] in counts:
                counts[row['status']] = row['count']
            total += row['count']
        
        # Pending is Applied + Under Review
        pending = counts['Applied'] + counts['Under Review']

        return {
            'total': total,
            'counts': counts,
            'shortlisted': counts['Shortlisted'],
            'interview_scheduled': counts['Interview Scheduled'],
            'selected': counts['Selected'],
            'rejected': counts['Rejected'],
            'pending': pending
        }

    @staticmethod
    def get_domain_distribution(user_id):
        query = """
            SELECT domain, COUNT(*) as count 
            FROM applications 
            WHERE user_id = ? AND domain IS NOT NULL AND domain != ''
            GROUP BY domain
            ORDER BY count DESC
        """
        return query_db(query, (user_id,))

    @staticmethod
    def get_recent_all(limit=15):
        query = """
            SELECT a.*, u.full_name as student_name, u.email as student_email
            FROM applications a
            JOIN users u ON a.user_id = u.id
            ORDER BY a.created_at DESC
            LIMIT ?
        """
        return query_db(query, (limit,))

    @staticmethod
    def get_platform_stats():
        users_count = query_db("SELECT COUNT(*) as count FROM users WHERE role = 'student'", one=True)['count']
        internships_count = query_db("SELECT COUNT(*) as count FROM internships WHERE is_active = 1", one=True)['count']
        applications_count = query_db("SELECT COUNT(*) as count FROM applications", one=True)['count']
        selected_count = query_db("SELECT COUNT(*) as count FROM applications WHERE status = 'Selected'", one=True)['count']
        shortlisted_count = query_db("SELECT COUNT(*) as count FROM applications WHERE status = 'Shortlisted'", one=True)['count']
        
        return {
            'total_students': users_count,
            'total_internships': internships_count,
            'total_applications': applications_count,
            'total_selected': selected_count,
            'total_shortlisted': shortlisted_count,
        }

