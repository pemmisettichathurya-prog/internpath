// Dashboard Analytics with Chart.js

function initDashboardCharts(statusLabels, statusValues, domainLabels, domainValues) {
    // 1. Status Breakdown Donut Chart
    const statusCtx = document.getElementById('applicationStatusChart');
    if (statusCtx) {
        const totalApps = statusValues.reduce((a, b) => a + b, 0);

        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: statusLabels,
                datasets: [{
                    data: totalApps > 0 ? statusValues : [1],
                    backgroundColor: totalApps > 0 ? [
                        '#3b82f6', // Applied (blue)
                        '#f59e0b', // Under Review (amber)
                        '#8b5cf6', // Shortlisted (violet)
                        '#06b6d4', // Interview Scheduled (cyan)
                        '#10b981', // Selected (emerald)
                        '#ef4444'  // Rejected (rose)
                    ] : ['#e2e8f0'],
                    borderWidth: 2,
                    borderColor: '#ffffff',
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '72%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            padding: 15,
                            font: { family: "'Plus Jakarta Sans', sans-serif", size: 12, weight: '500' }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                if (totalApps === 0) return ' No applications tracked yet';
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const percentage = Math.round((value / totalApps) * 100);
                                return ` ${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    // 2. Domain Distribution Bar Chart
    const domainCtx = document.getElementById('domainDistributionChart');
    if (domainCtx) {
        new Chart(domainCtx, {
            type: 'bar',
            data: {
                labels: domainLabels,
                datasets: [{
                    label: 'Applications',
                    data: domainValues,
                    backgroundColor: 'rgba(79, 70, 229, 0.85)',
                    hoverBackgroundColor: '#4f46e5',
                    borderRadius: 8,
                    maxBarThickness: 32
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            font: { family: "'Inter', sans-serif", size: 11 }
                        },
                        grid: { color: '#f1f5f9' }
                    },
                    x: {
                        ticks: {
                            font: { family: "'Inter', sans-serif", size: 11 }
                        },
                        grid: { display: false }
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function (ctx) {
                                return ` Applications: ${ctx.raw}`;
                            }
                        }
                    }
                }
            }
        });
    }
}

