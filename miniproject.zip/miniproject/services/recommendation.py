import re

class RecommendationEngine:
    """
    Transparent skill-based recommendation engine for student internship matching.
    Designed with a modular architecture ready for machine learning/vector embedding integration.
    """

    # Domain synonyms and related fields mapping
    DOMAIN_AFFINITIES = {
        'artificial intelligence': ['machine learning', 'data science', 'python development'],
        'machine learning': ['artificial intelligence', 'data science', 'python development'],
        'data science': ['machine learning', 'artificial intelligence', 'python development'],
        'python development': ['web development', 'data science', 'artificial intelligence'],
        'web development': ['ui/ux design', 'python development', 'cloud computing'],
        'cloud computing': ['cybersecurity', 'web development', 'java development'],
        'cybersecurity': ['cloud computing', 'python development'],
        'ui/ux design': ['web development', 'digital marketing'],
        'digital marketing': ['ui/ux design', 'data science'],
        'java development': ['cloud computing', 'web development']
    }

    @staticmethod
    def _normalize_tokens(text):
        """Extracts normalized clean skill tokens from string or list."""
        if not text:
            return set()
        
        # Split by commas, slashes, semicolons, and pipes
        raw_parts = re.split(r'[,/;|\n]+', str(text).lower())
        tokens = set()
        for p in raw_parts:
            cleaned = p.strip()
            # Clean common prefixes/suffixes
            cleaned = re.sub(r'\s+', ' ', cleaned)
            if cleaned:
                tokens.add(cleaned)
                # Also handle synonyms (e.g. 'ml' -> 'machine learning')
                if cleaned == 'ml':
                    tokens.add('machine learning')
                elif cleaned == 'ai':
                    tokens.add('artificial intelligence')
                elif cleaned == 'react':
                    tokens.add('react.js')
                elif cleaned == 'node':
                    tokens.add('node.js')
        return tokens

    @classmethod
    def calculate_match(cls, student, internship):
        """
        Calculates a matching percentage and detailed explanation between
        a student profile and an internship listing.
        """
        student_skills = cls._normalize_tokens(student.get('skills', ''))
        intern_skills = cls._normalize_tokens(internship.get('required_skills', ''))

        matched_skills = []
        missing_skills = []

        # Find matching skills (exact or substring matching)
        for isk in intern_skills:
            matched = False
            for ssk in student_skills:
                if isk == ssk or isk in ssk or ssk in isk:
                    matched = True
                    matched_skills.append(isk.title())
                    break
            if not matched:
                missing_skills.append(isk.title())

        # 1. Base skill match score (0 to 60 points)
        if intern_skills:
            skill_ratio = len(matched_skills) / len(intern_skills)
            skill_score = min(60.0, skill_ratio * 60.0)
        else:
            skill_score = 30.0

        # 2. Domain alignment score (0 to 25 points)
        domain_score = 0.0
        domain_match = False
        student_domain = (student.get('preferred_domain') or '').strip().lower()
        intern_domain = (internship.get('domain') or '').strip().lower()

        if student_domain and intern_domain:
            if student_domain == intern_domain:
                domain_score = 25.0
                domain_match = True
            elif intern_domain in cls.DOMAIN_AFFINITIES.get(student_domain, []):
                domain_score = 15.0
                domain_match = True

        # 3. Location / Work Mode alignment (0 to 15 points)
        location_score = 0.0
        location_match = False
        student_loc = (student.get('preferred_location') or '').strip().lower()
        intern_loc = (internship.get('location') or '').strip().lower()
        intern_mode = (internship.get('work_mode') or '').strip().lower()

        if intern_mode == 'remote':
            location_score = 15.0
            location_match = True
        elif student_loc and (student_loc in intern_loc or student_loc == 'remote'):
            location_score = 15.0
            location_match = True
        elif student_loc:
            location_score = 5.0

        # Total Raw Score
        raw_score = skill_score + domain_score + location_score
        match_percentage = int(round(raw_score))

        # Clamp between 10% and 98% (unless 100% full match)
        if len(matched_skills) == len(intern_skills) and domain_match and location_match:
            match_percentage = 99
        else:
            match_percentage = max(15, min(96, match_percentage))

        # Determine Tier
        if match_percentage >= 80:
            tier = 'Top Match'
            badge_class = 'bg-success'
        elif match_percentage >= 65:
            tier = 'Strong Match'
            badge_class = 'bg-primary'
        elif match_percentage >= 45:
            tier = 'Good Match'
            badge_class = 'bg-info'
        else:
            tier = 'Fair Match'
            badge_class = 'bg-secondary'

        # Build Explanation Summary
        explanation_parts = []
        if matched_skills:
            skills_str = ", ".join(matched_skills[:3])
            if len(matched_skills) > 3:
                skills_str += f" +{len(matched_skills)-3} more"
            explanation_parts.append(f"Matches your skills: <strong>{skills_str}</strong>")
        else:
            explanation_parts.append("Broad foundation match")

        if domain_match:
            explanation_parts.append(f"Aligns with your interest in <strong>{internship.get('domain')}</strong>")

        if location_match:
            if intern_mode == 'remote':
                explanation_parts.append("Offers remote flexibility")
            else:
                explanation_parts.append(f"Located in your preferred area ({internship.get('location')})")

        return {
            'percentage': match_percentage,
            'tier': tier,
            'badge_class': badge_class,
            'matched_skills': matched_skills,
            'missing_skills': missing_skills,
            'domain_match': domain_match,
            'location_match': location_match,
            'explanation': " • ".join(explanation_parts)
        }

    @classmethod
    def get_recommendations_for_user(cls, student, internships, limit=6):
        """
        Takes a student dict and a list of internship dicts, calculates match scores,
        and returns the internships sorted by match percentage descending.
        """
        if not student:
            return []

        scored_internships = []
        for item in internships:
            match_data = cls.calculate_match(student, item)
            item_copy = dict(item)
            item_copy['match'] = match_data
            scored_internships.append(item_copy)

        # Sort by match percentage descending
        scored_internships.sort(key=lambda x: x['match']['percentage'], reverse=True)

        return scored_internships[:limit]

