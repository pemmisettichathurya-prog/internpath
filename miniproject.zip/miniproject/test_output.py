from database.db import get_db_connection
from models.user import UserModel
from models.internship import InternshipModel
from models.application import ApplicationModel
from services.recommendation import RecommendationEngine
from services.deadline_service import DeadlineService

def generate_report():
    conn = get_db_connection()
    print("================================================================")
    print("       INTERNPATH PLATFORM – LIVE SYSTEM OUTPUT REPORT          ")
    print("================================================================\n")

    # 1. Database summary
    users_count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    internships_count = conn.execute("SELECT COUNT(*) FROM internships").fetchone()[0]
    apps_count = conn.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
    saved_count = conn.execute("SELECT COUNT(*) FROM saved_internships").fetchone()[0]

    print("📊 1. DATABASE METRICS:")
    print(f"   • Total Registered Users:      {users_count}")
    print(f"   • Active Internship Listings:  {internships_count}")
    print(f"   • Tracked Applications:        {apps_count}")
    print(f"   • Bookmarked Saved Listings:   {saved_count}\n")

    # 2. Student Profile
    student = UserModel.get_by_id(2)
    print("👤 2. ACTIVE STUDENT PROFILE (Alex Johnson):")
    print(f"   • Name:             {student['full_name']}")
    print(f"   • Email:            {student['email']}")
    print(f"   • College:          {student['college_name']} ({student['degree']} in {student['branch']})")
    print(f"   • Skills Profile:   {student['skills']}")
    print(f"   • Target Domain:    {student['preferred_domain']}")
    print(f"   • Location Pref:    {student['preferred_location']}\n")

    # 3. Recommendation Engine
    all_internships = InternshipModel.get_all()
    recommendations = RecommendationEngine.get_recommendations_for_user(student, all_internships, limit=4)
    print("🤖 3. SMART RECOMMENDATION ENGINE (AI Matching Output):")
    for i, rec in enumerate(recommendations, 1):
        m = rec['match']
        print(f"   [{i}] {rec['title']} ({rec['company_name']})")
        print(f"       ├── Match Compatibility: {m['percentage']}% ({m['tier']})")
        print(f"       ├── Matched Skills:      {', '.join(m['matched_skills'])}")
        print(f"       ├── Skills to Learn:     {', '.join(m['missing_skills'][:3])}")
        print(f"       └── Match Rationale:     {m['explanation'].replace('<strong>', '').replace('</strong>', '')}\n")

    # 4. Kanban Stages
    app_stats = ApplicationModel.get_user_stats(2)
    print("📋 4. APPLICATION TRACKER (Kanban Pipeline):")
    print(f"   • Total Active Applications: {app_stats['total']}")
    for st, count in app_stats['counts'].items():
        bar = "█" * (count * 3)
        print(f"   • {st:<20} : {count} app(s)  {bar}")
    print()

    # 5. Deadline Reminders
    user_apps = ApplicationModel.get_by_user(2)
    upcoming = DeadlineService.get_upcoming_deadlines_for_user(user_apps, limit=5)
    print("⏰ 5. DEADLINE & INTERVIEW REMINDER ENGINE:")
    for item in upcoming:
        a = item['analysis']
        icon = "🔴" if a['alert_level'] == 'danger' else ("🟡" if a['alert_level'] == 'warning' else "🔵")
        print(f"   {icon} [{a['label']}] {item['app']['role_title']} at {item['app']['company_name']}")
        print(f"      └── Event: {item['event_type']} on {a['formatted']}\n")

    # 6. Admin Stats
    platform_stats = ApplicationModel.get_platform_stats()
    print("🛡️  6. ADMINISTRATOR PLATFORM HEALTH:")
    print(f"   • Total Students:      {platform_stats['total_students']}")
    print(f"   • Total Internships:   {platform_stats['total_internships']}")
    print(f"   • Applications Filed:  {platform_stats['total_applications']}")
    print(f"   • Shortlisted:         {platform_stats['total_shortlisted']}")
    print(f"   • Confirmed Offers:    {platform_stats['total_selected']}")
    print("================================================================")

if __name__ == '__main__':
    generate_report()

