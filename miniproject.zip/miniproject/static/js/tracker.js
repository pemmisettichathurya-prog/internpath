// Kanban Drag-and-Drop & Application Tracker Interactions

document.addEventListener('DOMContentLoaded', function () {
    const cards = document.querySelectorAll('.kanban-card');
    const columns = document.querySelectorAll('.kanban-column-body');

    let draggedCard = null;

    // 1. Drag and Drop events
    cards.forEach(card => {
        card.addEventListener('dragstart', function (e) {
            draggedCard = this;
            this.classList.add('dragging');
            e.dataTransfer.setData('text/plain', this.getAttribute('data-app-id'));
            e.dataTransfer.effectAllowed = 'move';
        });

        card.addEventListener('dragend', function () {
            this.classList.remove('dragging');
            draggedCard = null;
        });
    });

    columns.forEach(column => {
        column.addEventListener('dragover', function (e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            this.classList.add('kanban-column-dragover');
        });

        column.addEventListener('dragleave', function () {
            this.classList.remove('kanban-column-dragover');
        });

        column.addEventListener('drop', function (e) {
            e.preventDefault();
            this.classList.remove('kanban-column-dragover');

            if (!draggedCard) return;

            const targetStatus = this.getAttribute('data-status');
            const appId = draggedCard.getAttribute('data-app-id');
            const originalStatus = draggedCard.getAttribute('data-status');

            if (targetStatus === originalStatus) return;

            // Move element in DOM
            this.appendChild(draggedCard);
            draggedCard.setAttribute('data-status', targetStatus);

            // Update column badges
            updateColumnCounters();

            // Send AJAX update to backend
            fetch(`/applications/${appId}/status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ status: targetStatus })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast(`Status updated to ${targetStatus}!`, 'success');
                } else {
                    showToast('Failed to update status', 'error');
                }
            })
            .catch(err => {
                console.error(err);
                showToast('Network error updating status', 'error');
            });
        });
    });

    function updateColumnCounters() {
        document.querySelectorAll('.kanban-column').forEach(col => {
            const status = col.querySelector('.kanban-column-body').getAttribute('data-status');
            const count = col.querySelectorAll('.kanban-card').length;
            const badge = col.querySelector('.column-count-badge');
            if (badge) badge.textContent = count;
        });
    }

    // 2. Pre-fill Edit Modal
    const editModal = document.getElementById('editApplicationModal');
    if (editModal) {
        editModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const appId = button.getAttribute('data-id');
            const company = button.getAttribute('data-company');
            const role = button.getAttribute('data-role');
            const domain = button.getAttribute('data-domain');
            const status = button.getAttribute('data-status');
            const appliedDate = button.getAttribute('data-applied');
            const interviewDate = button.getAttribute('data-interview');
            const deadline = button.getAttribute('data-deadline');
            const stipend = button.getAttribute('data-stipend');
            const location = button.getAttribute('data-location');
            const url = button.getAttribute('data-url');
            const notes = button.getAttribute('data-notes');

            const form = document.getElementById('editApplicationForm');
            form.action = `/applications/${appId}/update`;

            document.getElementById('editAppId').value = appId;
            document.getElementById('editCompany').value = company || '';
            document.getElementById('editRole').value = role || '';
            document.getElementById('editDomain').value = domain || '';
            document.getElementById('editStatus').value = status || 'Applied';
            document.getElementById('editAppliedDate').value = appliedDate || '';
            document.getElementById('editInterviewDate').value = interviewDate || '';
            document.getElementById('editDeadline').value = deadline || '';
            document.getElementById('editStipend').value = stipend || '';
            document.getElementById('editLocation').value = location || '';
            document.getElementById('editUrl').value = url || '';
            document.getElementById('editNotes').value = notes || '';
        });
    }

    // 3. Status quick-changer select listener for Table View
    document.querySelectorAll('.table-status-select').forEach(select => {
        select.addEventListener('change', function () {
            const appId = this.getAttribute('data-app-id');
            const newStatus = this.value;

            fetch(`/applications/${appId}/status`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ status: newStatus })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast(`Updated to ${newStatus}`, 'success');
                }
            });
        });
    });
});

