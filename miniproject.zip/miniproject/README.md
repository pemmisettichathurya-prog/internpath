# InternPath – Smart Student Internship Tracker and Finder

> **A modern, responsive, and intelligent internship discovery and application management platform designed specifically for college students and freshers.**

---

## 📌 1. Project Overview

Finding and tracking internships during college is traditionally fragmented across job boards, messaging apps, and disorganized spreadsheets. **InternPath** solves this by unifying:
1. **Intelligent Discovery**: Instant skill-based compatibility scoring that tells students *why* an opportunity fits them.
2. **Standardized Application Tracking**: Interactive Kanban and Table views to monitor hiring pipelines from *Applied* to *Offer Selected*.
3. **Automated Deadline Reminders**: Proactive alerts for deadlines approaching within 3 days and scheduled interview reminders.
4. **Verified Student Profiles**: Academic qualifications, verified PDF resume upload, and portfolio links in a single location.
5. **Administrative Management**: Full control to publish, modify, and monitor opportunities across 10 high-growth domains.

---

## 🛠️ 2. Technology Stack

### **Frontend**
- **HTML5 & CSS3**: Modern SaaS aesthetic, responsive layouts, CSS variables, and glassmorphism.
- **Bootstrap 5.3**: Responsive grid, modal dialogs, pills, tooltips, and alerts.
- **Bootstrap Icons**: Crisp SVG icons for intuitive visual cues.
- **JavaScript (ES6+)**: Dynamic Kanban drag-and-drop, AJAX bookmark saving, status switches, and interactive notifications.
- **Chart.js (v4.4)**: Interactive donut charts for application statuses and bar charts for domain distributions.

### **Backend**
- **Python 3.11+**
- **Flask Framework**: Blueprint-based modular routing, session management, and template context processors.
- **Werkzeug Security**: Cryptographic password hashing (`generate_password_hash` & `check_password_hash`) and secure file upload handling.
- **Python Datetime**: Dynamic deadline calculations, countdown categorization, and interview alerts.

### **Database**
- **SQLite3**: Lightweight, zero-configuration relational database with foreign key integrity.

---

## 📂 3. Project Structure

```text
miniproject/
│
├── app.py                      # Application factory, blueprint registrations & error handlers
├── config.py                   # Global configuration (paths, secret keys, upload limits)
├── requirements.txt            # Python dependencies
├── README.md                   # Complete documentation and user manual
│
├── database/
│   ├── db.py                   # SQLite helper connections and transaction queries
│   ├── schema.sql              # Relational database schema with 5 core tables
│   ├── db_setup.py             # Seeder script generating 22 realistic demo listings
│   └── internpath.db           # SQLite database file (auto-created on launch)
│
├── models/
│   ├── user.py                 # User authentication, profiles, and student queries
│   ├── internship.py           # Multi-filter search queries and listing CRUD
│   ├── application.py          # Application tracker operations and platform metrics
│   └── notification.py         # In-app notifications and alert logging
│
├── services/
│   ├── recommendation.py       # Transparent skill-matching algorithm
│   └── deadline_service.py     # Date calculation and deadline classification
│
├── routes/
│   ├── auth.py                 # Registration, login, logout, and RBAC decorators
│   ├── dashboard.py            # Student dashboard and Chart.js analytics
│   ├── internships.py          # Internship finder, detail view, and bookmarking
│   ├── applications.py         # Kanban tracker, table view, and status updates
│   ├── profile.py              # Profile editing, resume upload & verification
│   ├── admin.py                # Admin console, listing management, student directory
│   └── notifications.py        # Notification dismissal and status updates
│
├── static/
│   ├── css/
│   │   └── style.css           # Modern SaaS stylesheet, custom badges, Kanban styles
│   ├── js/
│   │   ├── main.js             # AJAX bookmarking, auto-dismiss alerts, tooltips
│   │   ├── dashboard-charts.js # Chart.js chart initializations
│   │   └── tracker.js          # Kanban drag-and-drop & status sync
│   └── uploads/
│       └── resumes/            # Secure storage directory for student PDF resumes
│
└── templates/
    ├── base.html               # Master layout with responsive navbar & sidebar
    ├── landing.html            # Public landing page with hero, stats, and categories
    ├── auth/
    │   ├── login.html          # Authentication page with demo credentials
    │   └── register.html       # Comprehensive student onboarding form
    ├── dashboard/
    │   └── index.html          # Metric cards, Chart.js analytics, urgent alerts
    ├── internships/
    │   ├── index.html          # Filterable finder with search and match tags
    │   ├── detail.html         # Detailed listing view with match explanation
    │   └── saved.html          # Bookmarked favourite internships
    ├── applications/
    │   └── index.html          # Dual-view Kanban Board & Table tracker
    ├── profile/
    │   └── index.html          # Profile settings, completion bar & resume upload
    ├── admin/
    │   ├── dashboard.html      # Platform overview metrics and live feed
    │   ├── internships.html    # Listing management table (active/inactive toggle)
    │   ├── internship_form.html# Add & Edit opportunity form
    │   └── students.html       # Registered students directory
    └── errors/
        ├── 404.html            # Not Found page
        └── 500.html            # Internal Server Error page
```

---

## 🗄️ 4. Database Schema Documentation

### **1. `users` Table**
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PRIMARY KEY | Unique student/admin identifier |
| `full_name` | TEXT | User's full name |
| `email` | TEXT UNIQUE | Login email address |
| `password_hash` | TEXT | Cryptographic hash generated by Werkzeug |
| `role` | TEXT | `'student'` or `'admin'` (RBAC enforced) |
| `college_name` | TEXT | Educational institution |
| `degree` | TEXT | Degree qualification (e.g. B.Tech, B.S.) |
| `branch` | TEXT | Major / specialization (e.g. Computer Science) |
| `graduation_year` | INTEGER | Expected graduation year |
| `skills` | TEXT | Comma-separated list of technical skills |
| `preferred_domain`| TEXT | Preferred internship category |
| `preferred_location`| TEXT | Remote, city preference |
| `resume_filename` | TEXT | Stored unique filename for PDF resume |
| `portfolio_url` | TEXT | Personal portfolio URL |
| `linkedin_url` | TEXT | LinkedIn profile URL |
| `github_url` | TEXT | GitHub profile URL |
| `created_at` | DATETIME | Registration timestamp |

### **2. `internships` Table**
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PRIMARY KEY | Opportunity identifier |
| `title` | TEXT | Internship role title |
| `company_name` | TEXT | Hiring organization |
| `domain` | TEXT | Domain category (AI, Web, Data Science, etc.) |
| `required_skills`| TEXT | Required technologies for matching algorithm |
| `description` | TEXT | Full position overview |
| `responsibilities`| TEXT | Core daily tasks |
| `eligibility` | TEXT | Academic or skill criteria |
| `stipend` | TEXT | Display stipend (e.g., "$3,800/month") |
| `stipend_amount` | INTEGER | Numerical stipend for range filtering |
| `stipend_type` | TEXT | `'Paid'` or `'Unpaid'` |
| `location` | TEXT | Office location or city |
| `work_mode` | TEXT | `'Remote'`, `'Hybrid'`, or `'Onsite'` |
| `deadline` | DATE | Application closing date |
| `application_url`| TEXT | External official application link |
| `is_active` | INTEGER | 1 for live, 0 for paused/hidden |

### **3. `applications` Table**
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PRIMARY KEY | Application tracking ID |
| `user_id` | INTEGER | FK -> `users(id)` |
| `internship_id`| INTEGER | FK -> `internships(id)` (nullable for manual apps) |
| `company_name` | TEXT | Organization name |
| `role_title` | TEXT | Position applied for |
| `domain` | TEXT | Category field |
| `status` | TEXT | Stage: `Applied`, `Under Review`, `Shortlisted`, `Interview Scheduled`, `Selected`, `Rejected` |
| `applied_date` | DATE | Date application was submitted |
| `interview_date`| DATE | Date of upcoming technical/HR interview |
| `deadline` | DATE | Target closing deadline |
| `notes` | TEXT | Custom student notes and interview prep tasks |

### **4. `saved_internships` Table**
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PRIMARY KEY | Bookmark entry ID |
| `user_id` | INTEGER | FK -> `users(id)` |
| `internship_id`| INTEGER | FK -> `internships(id)` |
| `created_at` | DATETIME | Bookmark timestamp |

### **5. `notifications` Table**
| Column | Type | Description |
|---|---|---|
| `id` | INTEGER PRIMARY KEY | Notification ID |
| `user_id` | INTEGER | FK -> `users(id)` |
| `title` | TEXT | Alert headline |
| `message` | TEXT | Detailed reminder description |
| `type` | TEXT | `'deadline'`, `'interview'`, `'status'`, `'info'` |
| `is_read` | INTEGER | 0 for unread, 1 for read |
| `link` | TEXT | Target internal URL |

---

## ⚡ 5. Smart Recommendation Engine

The recommendation system calculates a compatibility score between 0% and 99% using three weighted dimensions:

1. **Skill Overlap (0 to 60 Points)**:
   - Tokenizes and cleans both the student's skills and the internship requirements.
   - Computes intersection ratio:
     $$\text{Skill Score} = \min\left(60.0, \frac{|\text{Matched Skills}|}{|\text{Required Skills}|} \times 60.0\right)$$
2. **Domain Alignment (0 to 25 Points)**:
   - Grants **25 points** for exact domain matches.
   - Grants **15 points** for related affinity domains (e.g., Machine Learning ↔ Data Science).
3. **Location / Remote Flexibility (0 to 15 Points)**:
   - Grants **15 points** if the internship is Remote or matches the student's preferred city.

**Match Explanations:**
Every recommendation displays human-readable rationales such as:
> *"Matches your skills: Python, PyTorch, Machine Learning • Aligns with your interest in Artificial Intelligence • Offers remote flexibility"*

---

## 🚀 6. Installation & Execution Guide

### **Prerequisites**
- Python 3.10+ installed on your computer.

### **Step 1: Clone or Navigate to Directory**
```bash
cd c:\Users\Chathurya\OneDrive\Desktop\miniproject
```

### **Step 2: Install Dependencies**
```bash
pip install -r requirements.txt
```

### **Step 3: Initialize Database & Seed Sample Listings**
```bash
python database/db_setup.py
```
*(Seeds 22 realistic listings, sample accounts, notifications, and application records)*

### **Step 4: Launch Web Server**
```bash
python app.py
```

### **Step 5: Access in Your Browser**
Open your browser and navigate to:
```text
http://127.0.0.1:5000
```

---

## 🔑 7. Pre-Seeded Demo Credentials

| Role | Email | Password | Access Level |
|---|---|---|---|
| **Student** | `alex.student@internpath.com` | `student123` | Student Dashboard, Finder, Kanban Tracker, Saved, Profile |
| **Admin** | `admin@internpath.com` | `admin123` | Platform Console, Internship CRUD, Student Directory |

*(You can also register a brand new student account directly from the registration page!)*

---

## 💡 8. Key Features Breakdown

- **Smart Internship Finder**:
  Filter by keyword, 10 technology domains, work mode (Remote/Hybrid/Onsite), compensation (Paid/Unpaid), minimum stipend, location, and required skills.
- **Application Tracker**:
  Dual-view Kanban board with drag-and-drop column transitions and Table view with 1-click status dropdowns.
- **Color-Coded Deadline Engine**:
  - 🔴 **Overdue / Due Today**: Red warning alert with pulse animation.
  - 🟡 **Closing in ≤ 3 Days**: Urgent amber indicator.
  - 🔵 **Approaching (4–7 Days)**: Info badge.
  - 🟢 **Upcoming (> 7 Days)**: Normal status.
- **Verified Resume Upload**:
  Secure PDF validator restricting unsupported file extensions and enforcing maximum 5MB size limits.
- **Admin Control**:
  Add new internship postings, modify listings, toggle public visibility, and inspect platform metrics.

