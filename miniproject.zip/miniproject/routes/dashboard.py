import json
from flask import Blueprint, render_template, session, redirect, url_for
from routes.auth import login_required
from models.user import UserModel
from models.internship import InternshipModel
from models.application import ApplicationModel
from models.notification import NotificationModel
from services.recommendation import RecommendationEngine
from services.deadline_service import DeadlineService

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard')
@login_required
def index():
    if session.get('role') == 'admin':
        return redirect(url_for('admin.index'))

    user_id = session['user_id']
    student = UserModel.get_by_id(user_id)
    if not student:
        session.clear()
        return redirect(url_for('auth.login'))

    # Stats
    app_stats = ApplicationModel.get_user_stats(user_id)
    all_internships = InternshipModel.get_all(include_inactive=False)
    total_internships = len(all_internships)

    # Saved internship IDs
    saved_ids = InternshipModel.get_saved_ids(user_id)

    # Recommendations
    recommendations = RecommendationEngine.get_recommendations_for_user(student, all_internships, limit=4)
    # Enrich recommendations with saved status and deadline analysis
    for rec in recommendations:
        rec['is_saved'] = rec['id'] in saved_ids
        rec['deadline_info'] = DeadlineService.analyze_deadline(rec.get('deadline'))

    # Applications and upcoming deadlines
    user_apps = ApplicationModel.get_by_user(user_id)
    upcoming_events = DeadlineService.get_upcoming_deadlines_for_user(user_apps, limit=5)

    # Urgent deadlines from general internships (closing in <= 3 days)
    urgent_internships = []
    for item in all_internships:
        analysis = DeadlineService.analyze_deadline(item['deadline'])
        if analysis['status'] in ('due_today', 'urgent'):
            item_copy = dict(item)
            item_copy['deadline_info'] = analysis
            item_copy['is_saved'] = item['id'] in saved_ids
            urgent_internships.append(item_copy)

    # Chart data
    chart_status_labels = ['Applied', 'Under Review', 'Shortlisted', 'Interview Scheduled', 'Selected', 'Rejected']
    chart_status_values = [app_stats['counts'].get(s, 0) for s in chart_status_labels]

    domain_dist = ApplicationModel.get_domain_distribution(user_id)
    chart_domain_labels = [d['domain'] for d in domain_dist] or ['No Data Yet']
    chart_domain_values = [d['count'] for d in domain_dist] or [0]

    # Notifications
    notifications = NotificationModel.get_by_user(user_id, limit=5)
    unread_count = NotificationModel.get_unread_count(user_id)

    return render_template(
        'dashboard/index.html',
        student=student,
        stats=app_stats,
        total_internships=total_internships,
        recommendations=recommendations,
        upcoming_events=upcoming_events,
        urgent_internships=urgent_internships[:3],
        chart_status_labels=json.dumps(chart_status_labels),
        chart_status_values=json.dumps(chart_status_values),
        chart_domain_labels=json.dumps(chart_domain_labels),
        chart_domain_values=json.dumps(chart_domain_values),
        notifications=notifications,
        unread_count=unread_count
    )

