from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g
from functools import wraps
from models.user import UserModel
from models.internship import InternshipModel

auth_bp = Blueprint('auth', __name__)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for('auth.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in to access admin area.", "warning")
            return redirect(url_for('auth.login', next=request.url))
        if session.get('role') != 'admin':
            flash("Access denied. Administrator privileges required.", "danger")
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated_function

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    domains = [
        "Artificial Intelligence",
        "Machine Learning",
        "Python Development",
        "Data Science",
        "Web Development",
        "Java Development",
        "Cloud Computing",
        "Cybersecurity",
        "Digital Marketing",
        "UI/UX Design"
    ]

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        college_name = request.form.get('college_name', '').strip()
        degree = request.form.get('degree', '').strip()
        branch = request.form.get('branch', '').strip()
        graduation_year = request.form.get('graduation_year', '').strip()
        skills = request.form.get('skills', '').strip()
        preferred_domain = request.form.get('preferred_domain', '').strip()

        # Validation
        errors = []
        if not full_name:
            errors.append("Full name is required.")
        if not email or '@' not in email:
            errors.append("A valid email address is required.")
        if not password or len(password) < 6:
            errors.append("Password must be at least 6 characters long.")
        if password != confirm_password:
            errors.append("Passwords do not match.")

        # Check existing user
        if not errors:
            existing = UserModel.get_by_email(email)
            if existing:
                errors.append("An account with this email already exists.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template('auth/register.html', domains=domains, form_data=request.form)

        try:
            grad_yr = int(graduation_year) if graduation_year.isdigit() else None
            user_id = UserModel.create(
                full_name=full_name,
                email=email,
                password=password,
                college_name=college_name,
                degree=degree,
                branch=branch,
                graduation_year=grad_yr,
                skills=skills,
                preferred_domain=preferred_domain,
                preferred_location="Remote"
            )

            # Auto-login
            session['user_id'] = user_id
            session['role'] = 'student'
            session['user_name'] = full_name
            session['email'] = email

            flash("Registration successful! Welcome to InternPath.", "success")
            return redirect(url_for('landing'))
        except Exception as e:
            flash(f"An error occurred while creating your account: {str(e)}", "danger")
            return render_template('auth/register.html', domains=domains, form_data=request.form)

    return render_template('auth/register.html', domains=domains, form_data={})

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        if session.get('role') == 'admin':
            return redirect(url_for('admin.index'))
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not email or not password:
            flash("Please enter both email and password.", "danger")
            return render_template('auth/login.html', email=email)

        user = UserModel.get_by_email(email)
        if not user or not UserModel.verify_password(user['password_hash'], password):
            flash("Invalid email or password. Please try again.", "danger")
            return render_template('auth/login.html', email=email)

        # Successful login
        session['user_id'] = user['id']
        session['role'] = user['role']
        session['user_name'] = user['full_name']
        session['email'] = user['email']

        flash(f"Welcome back, {user['full_name']}!", "success")

        next_page = request.args.get('next')
        if next_page and next_page.startswith('/'):
            return redirect(next_page)

        if user['role'] == 'admin':
            return redirect(url_for('admin.index'))
        return redirect(url_for('landing'))

    return render_template('auth/login.html', email='')

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash("You have been successfully logged out.", "info")
    return redirect(url_for('auth.login'))

