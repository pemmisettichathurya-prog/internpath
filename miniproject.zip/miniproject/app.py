import os
from flask import Flask, render_template, session, redirect, url_for, flash
from config import Config
from database.db_setup import seed_database
from models.user import UserModel
from models.internship import InternshipModel
from models.notification import NotificationModel

# Import Blueprints
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.internships import internships_bp
from routes.applications import applications_bp
from routes.profile import profile_bp
from routes.admin import admin_bp
from routes.notifications import notifications_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Ensure uploads directory exists
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # Initialize and seed database if it doesn't exist
    if not os.path.exists(app.config['DATABASE_PATH']):
        print("[InternPath] Database not found. Initializing and seeding...")
        seed_database()

    # Register Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(internships_bp)
    app.register_blueprint(applications_bp)
    app.register_blueprint(profile_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(notifications_bp)

    # Landing page route (Requires login first)
    @app.route('/')
    def landing():
        if 'user_id' not in session:
            flash("Please sign in to access InternPath.", "info")
            return redirect(url_for('auth.login'))
        
        # When logged in, render the first page!
        featured = InternshipModel.filter_internships(sort_by='deadline_asc')[:6]
        
        # Real domain counts from database
        from database.db import query_db
        db_counts = {r['domain']: r['count'] for r in query_db("SELECT domain, COUNT(*) as count FROM internships WHERE is_active = 1 GROUP BY domain")}
        
        domain_meta = [
            {"name": "Artificial Intelligence", "icon": "bi-cpu-fill", "color": "text-primary", "bg": "bg-primary-subtle", "tag": "🔥 Trending", "tag_class": "badge-soft-danger"},
            {"name": "Machine Learning", "icon": "bi-diagram-3-fill", "color": "text-purple", "bg": "bg-purple-subtle", "tag": "⭐ Top Pick", "tag_class": "badge-soft-primary"},
            {"name": "Python Development", "icon": "bi-code-slash", "color": "text-success", "bg": "bg-success-subtle", "tag": "🚀 High Demand", "tag_class": "badge-soft-success"},
            {"name": "Data Science", "icon": "bi-graph-up-arrow", "color": "text-info", "bg": "bg-info-subtle", "tag": "📊 Analytics", "tag_class": "badge-soft-info"},
            {"name": "Web Development", "icon": "bi-globe2", "color": "text-primary", "bg": "bg-primary-subtle", "tag": "💻 Full Stack", "tag_class": "badge-soft-primary"},
            {"name": "Java Development", "icon": "bi-cup-hot-fill", "color": "text-danger", "bg": "bg-danger-subtle", "tag": "🏢 Enterprise", "tag_class": "badge-soft-warning"},
            {"name": "Cloud Computing", "icon": "bi-cloud-check-fill", "color": "text-cyan", "bg": "bg-info-subtle", "tag": "☁️ Cloud", "tag_class": "badge-soft-info"},
            {"name": "Cybersecurity", "icon": "bi-shield-lock-fill", "color": "text-warning", "bg": "bg-warning-subtle", "tag": "🛡️ Defense", "tag_class": "badge-soft-warning"},
            {"name": "UI/UX Design", "icon": "bi-palette-fill", "color": "text-pink", "bg": "bg-danger-subtle", "tag": "🎨 Product", "tag_class": "badge-soft-danger"},
            {"name": "Digital Marketing", "icon": "bi-megaphone-fill", "color": "text-success", "bg": "bg-success-subtle", "tag": "📈 Growth", "tag_class": "badge-soft-success"}
        ]
        
        domains = []
        for d in domain_meta:
            count = db_counts.get(d['name'], 0)
            d['count'] = f"{count} Active Role{'s' if count != 1 else ''}"
            domains.append(d)
            
        return render_template('landing.html', featured=featured, domains=domains)

    # Global Context Processor
    @app.context_processor
    def inject_global_data():
        current_user = None
        unread_notifications_count = 0
        user_notifications = []

        if 'user_id' in session:
            current_user = UserModel.get_by_id(session['user_id'])
            unread_notifications_count = NotificationModel.get_unread_count(session['user_id'])
            user_notifications = NotificationModel.get_by_user(session['user_id'], limit=5)

        return {
            'current_user': current_user,
            'unread_notifications_count': unread_notifications_count,
            'header_notifications': user_notifications
        }

    # Error Handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html'), 500

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='127.0.0.1', port=5000)

