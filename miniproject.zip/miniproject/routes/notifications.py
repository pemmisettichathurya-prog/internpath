from flask import Blueprint, jsonify, request, session, redirect
from routes.auth import login_required
from models.notification import NotificationModel

notifications_bp = Blueprint('notifications', __name__)

@notifications_bp.route('/notifications/read-all', methods=['POST'])
@login_required
def mark_all_read():
    user_id = session['user_id']
    NotificationModel.mark_all_as_read(user_id)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
        return jsonify({'success': True})
    return redirect(request.referrer or '/')

@notifications_bp.route('/notifications/<int:id>/read', methods=['POST'])
@login_required
def mark_read(id):
    user_id = session['user_id']
    NotificationModel.mark_as_read(id, user_id)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.is_json:
        return jsonify({'success': True})
    return redirect(request.referrer or '/')

