from database.db import query_db, execute_db

class NotificationModel:
    @staticmethod
    def get_by_user(user_id, limit=10):
        query = """
            SELECT * FROM notifications 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        """
        return query_db(query, (user_id, limit))

    @staticmethod
    def get_unread_count(user_id):
        res = query_db("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0", (user_id,), one=True)
        return res['count'] if res else 0

    @staticmethod
    def mark_as_read(notification_id, user_id):
        execute_db("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", (notification_id, user_id))

    @staticmethod
    def mark_all_as_read(user_id):
        execute_db("UPDATE notifications SET is_read = 1 WHERE user_id = ?", (user_id,))

    @staticmethod
    def create(user_id, title, message, type='info', link=None):
        query = """
            INSERT INTO notifications (user_id, title, message, type, is_read, link)
            VALUES (?, ?, ?, ?, 0, ?)
        """
        return execute_db(query, (user_id, title, message, type, link))

