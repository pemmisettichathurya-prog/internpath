from database.db import query_db, execute_db

class InternshipModel:
    @staticmethod
    def get_by_id(internship_id):
        return query_db("SELECT * FROM internships WHERE id = ?", (internship_id,), one=True)

    @staticmethod
    def get_all(include_inactive=False):
        if include_inactive:
            return query_db("SELECT * FROM internships ORDER BY deadline ASC")
        return query_db("SELECT * FROM internships WHERE is_active = 1 ORDER BY deadline ASC")

    @staticmethod
    def filter_internships(search=None, domain=None, location=None, work_mode=None, stipend_type=None, min_stipend=None, skill=None, sort_by=None):
        query = "SELECT * FROM internships WHERE is_active = 1"
        params = []

        if search:
            query += " AND (LOWER(title) LIKE ? OR LOWER(company_name) LIKE ? OR LOWER(description) LIKE ?)"
            s = f"%{search.lower().strip()}%"
            params.extend([s, s, s])

        if domain and domain.lower() != 'all':
            query += " AND LOWER(domain) = LOWER(?)"
            params.append(domain.strip())

        if location and location.lower() != 'all':
            query += " AND (LOWER(location) LIKE ?)"
            params.append(f"%{location.lower().strip()}%")

        if work_mode and work_mode.lower() != 'all':
            query += " AND LOWER(work_mode) = LOWER(?)"
            params.append(work_mode.strip())

        if stipend_type and stipend_type.lower() != 'all':
            query += " AND LOWER(stipend_type) = LOWER(?)"
            params.append(stipend_type.strip())

        if min_stipend:
            try:
                min_val = int(min_stipend)
                query += " AND stipend_amount >= ?"
                params.append(min_val)
            except ValueError:
                pass

        if skill:
            query += " AND LOWER(required_skills) LIKE ?"
            params.append(f"%{skill.lower().strip()}%")

        # Sorting
        if sort_by == 'deadline_asc':
            query += " ORDER BY deadline ASC"
        elif sort_by == 'deadline_desc':
            query += " ORDER BY deadline DESC"
        elif sort_by == 'stipend_desc':
            query += " ORDER BY stipend_amount DESC"
        elif sort_by == 'newest':
            query += " ORDER BY created_at DESC"
        else:
            query += " ORDER BY deadline ASC"

        return query_db(query, tuple(params))

    @staticmethod
    def create(title, company_name, domain, required_skills, description, responsibilities, eligibility, stipend, stipend_amount, stipend_type, location, work_mode, deadline, application_url, created_by=None):
        query = """
            INSERT INTO internships 
            (title, company_name, domain, required_skills, description, responsibilities, eligibility, stipend, stipend_amount, stipend_type, location, work_mode, deadline, application_url, is_active, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        """
        return execute_db(query, (
            title.strip(), company_name.strip(), domain.strip(), required_skills.strip(),
            description.strip(), responsibilities.strip(), eligibility.strip(),
            stipend.strip(), stipend_amount or 0, stipend_type.strip(), location.strip(),
            work_mode.strip(), deadline.strip(), application_url.strip(), created_by
        ))

    @staticmethod
    def update(internship_id, title, company_name, domain, required_skills, description, responsibilities, eligibility, stipend, stipend_amount, stipend_type, location, work_mode, deadline, application_url, is_active):
        query = """
            UPDATE internships 
            SET title = ?, company_name = ?, domain = ?, required_skills = ?, description = ?, 
                responsibilities = ?, eligibility = ?, stipend = ?, stipend_amount = ?, stipend_type = ?, 
                location = ?, work_mode = ?, deadline = ?, application_url = ?, is_active = ?
            WHERE id = ?
        """
        execute_db(query, (
            title.strip(), company_name.strip(), domain.strip(), required_skills.strip(),
            description.strip(), responsibilities.strip(), eligibility.strip(),
            stipend.strip(), stipend_amount or 0, stipend_type.strip(), location.strip(),
            work_mode.strip(), deadline.strip(), application_url.strip(), 1 if is_active else 0,
            internship_id
        ))

    @staticmethod
    def delete(internship_id):
        execute_db("DELETE FROM internships WHERE id = ?", (internship_id,))

    @staticmethod
    def toggle_status(internship_id):
        execute_db("UPDATE internships SET is_active = (CASE WHEN is_active = 1 THEN 0 ELSE 1 END) WHERE id = ?", (internship_id,))

    # Saved Internships helpers
    @staticmethod
    def is_saved(user_id, internship_id):
        res = query_db("SELECT 1 FROM saved_internships WHERE user_id = ? AND internship_id = ?", (user_id, internship_id), one=True)
        return res is not None

    @staticmethod
    def save_internship(user_id, internship_id):
        query = "INSERT OR IGNORE INTO saved_internships (user_id, internship_id) VALUES (?, ?)"
        execute_db(query, (user_id, internship_id))

    @staticmethod
    def unsave_internship(user_id, internship_id):
        query = "DELETE FROM saved_internships WHERE user_id = ? AND internship_id = ?"
        execute_db(query, (user_id, internship_id))

    @staticmethod
    def get_saved_internships(user_id):
        query = """
            SELECT i.*, s.created_at as saved_at 
            FROM internships i 
            JOIN saved_internships s ON i.id = s.internship_id 
            WHERE s.user_id = ?
            ORDER BY s.created_at DESC
        """
        return query_db(query, (user_id,))

    @staticmethod
    def get_saved_ids(user_id):
        rows = query_db("SELECT internship_id FROM saved_internships WHERE user_id = ?", (user_id,))
        return {r['internship_id'] for r in rows}

    @staticmethod
    def get_domains():
        rows = query_db("SELECT DISTINCT domain FROM internships ORDER BY domain ASC")
        return [r['domain'] for r in rows if r['domain']]

    @staticmethod
    def get_locations():
        rows = query_db("SELECT DISTINCT location FROM internships ORDER BY location ASC")
        return [r['location'] for r in rows if r['location']]

