import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'internpath-super-secret-key-2026-production')
    DATABASE_PATH = os.path.join(BASE_DIR, 'database', 'internpath.db')
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads', 'resumes')
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5 MB max file upload
    ALLOWED_EXTENSIONS = {'pdf'}
    DEBUG = True

