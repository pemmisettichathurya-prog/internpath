import os
import uuid
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, current_app, send_from_directory
from werkzeug.utils import secure_filename
from routes.auth import login_required
from models.user import UserModel
from config import Config

profile_bp = Blueprint('profile', __name__)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in Config.ALLOWED_EXTENSIONS

@profile_bp.route('/profile')
@login_required
def index():
    user_id = session['user_id']
    student = UserModel.get_by_id(user_id)
    if not student:
        flash("Student profile not found.", "danger")
        return redirect(url_for('auth.login'))

    domains = [
        "Artificial Intelligence",
        "Machine Learning",
        "Python Development",
        "Data Science",
        "Web Development",
        "Java Development",
        "Cloud Computing",
        "Cybersecurity",
        "Digital Marketing",
        "UI/UX Design"
    ]

    # Calculate profile completion percentage
    fields_to_check = [
        student['full_name'], student['email'], student['college_name'], student['degree'],
        student['branch'], student['graduation_year'], student['skills'],
        student['preferred_domain'], student['preferred_location'],
        student['resume_filename'], student['linkedin_url'], student['github_url']
    ]
    filled = sum(1 for f in fields_to_check if f)
    completion_percentage = int((filled / len(fields_to_check)) * 100)

    # Split skills for display
    student_skills_list = [s.strip() for s in (student['skills'] or '').split(',') if s.strip()]

    return render_template(
        'profile/index.html',
        student=student,
        domains=domains,
        skills_list=student_skills_list,
        completion_percentage=completion_percentage
    )

@profile_bp.route('/profile/update', methods=['POST'])
@login_required
def update():
    user_id = session['user_id']
    full_name = request.form.get('full_name', '').strip()
    college_name = request.form.get('college_name', '').strip()
    degree = request.form.get('degree', '').strip()
    branch = request.form.get('branch', '').strip()
    graduation_year = request.form.get('graduation_year', '').strip()
    skills = request.form.get('skills', '').strip()
    preferred_domain = request.form.get('preferred_domain', '').strip()
    preferred_location = request.form.get('preferred_location', '').strip()
    portfolio_url = request.form.get('portfolio_url', '').strip()
    linkedin_url = request.form.get('linkedin_url', '').strip()
    github_url = request.form.get('github_url', '').strip()

    if not full_name:
        flash("Full name cannot be empty.", "danger")
        return redirect(url_for('profile.index'))

    grad_yr = int(graduation_year) if graduation_year.isdigit() else None

    UserModel.update_profile(
        user_id=user_id,
        full_name=full_name,
        college_name=college_name,
        degree=degree,
        branch=branch,
        graduation_year=grad_yr,
        skills=skills,
        preferred_domain=preferred_domain,
        preferred_location=preferred_location,
        portfolio_url=portfolio_url,
        linkedin_url=linkedin_url,
        github_url=github_url
    )

    # Update session name if changed
    session['user_name'] = full_name

    flash("Profile updated successfully!", "success")
    return redirect(url_for('profile.index'))

@profile_bp.route('/profile/upload-resume', methods=['POST'])
@login_required
def upload_resume():
    user_id = session['user_id']
    if 'resume' not in request.files:
        flash("No file part in the request.", "danger")
        return redirect(url_for('profile.index'))

    file = request.files['resume']
    if file.filename == '':
        flash("Please select a file to upload.", "warning")
        return redirect(url_for('profile.index'))

    if not allowed_file(file.filename):
        flash("Invalid file format. Only PDF files (.pdf) are supported.", "danger")
        return redirect(url_for('profile.index'))

    # Ensure uploads directory exists
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

    # Generate unique safe filename
    original_ext = file.filename.rsplit('.', 1)[1].lower()
    unique_filename = f"resume_user_{user_id}_{uuid.uuid4().hex[:8]}.{original_ext}"
    destination_path = os.path.join(Config.UPLOAD_FOLDER, unique_filename)

    file.save(destination_path)
    UserModel.update_resume(user_id, unique_filename)

    flash("Resume uploaded and verified successfully!", "success")
    return redirect(url_for('profile.index'))

@profile_bp.route('/profile/resume/<filename>')
@login_required
def download_resume(filename):
    safe_name = secure_filename(filename)
    return send_from_directory(Config.UPLOAD_FOLDER, safe_name, as_attachment=False)

