import os
import sys
from datetime import date, timedelta
from werkzeug.security import generate_password_hash

# Ensure root directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from database.db import get_db_connection, init_db

def seed_database():
    """Initializes tables and populates realistic demo data."""
    init_db()
    conn = get_db_connection()
    cur = conn.cursor()

    today = date.today()

    # 1. Seed Users (Admin & Sample Student)
    admin_pass = generate_password_hash("admin123")
    student_pass = generate_password_hash("student123")

    cur.execute("""
        INSERT OR IGNORE INTO users (id, full_name, email, password_hash, role, college_name, degree, branch, graduation_year, skills, preferred_domain, preferred_location, portfolio_url, linkedin_url, github_url)
        VALUES 
        (1, 'System Administrator', 'admin@internpath.com', ?, 'admin', 'National Institute of Technology', 'M.Tech', 'Computer Science', 2022, 'Python, System Architecture, Database Management, Security', 'Web Development', 'Bangalore', 'https://admin.internpath.dev', 'https://linkedin.com/in/internpath-admin', 'https://github.com/internpath-admin'),
        (2, 'Alex Johnson', 'alex.student@internpath.com', ?, 'student', 'Stanford University', 'B.S.', 'Computer Science', 2026, 'Python, Machine Learning, SQL, PyTorch, React, Data Analysis', 'Artificial Intelligence', 'Remote', 'https://alexjohnson.dev', 'https://linkedin.com/in/alex-johnson-dev', 'https://github.com/alexjohnson-tech')
    """, (admin_pass, student_pass))

    # 2. Seed 22 Sample Internships
    internships_data = [
        (
            1,
            "AI & Machine Learning Research Intern",
            "OpenAI Research Lab",
            "Artificial Intelligence",
            "Python, PyTorch, Machine Learning, Deep Learning, NLP, Mathematics",
            "Join our frontier AI alignment and foundational model research group. You will collaborate with research scientists on experimenting with large language models, evaluation frameworks, and RLHF pipelines.",
            "Assist in training experiments, analyze attention patterns, curate high-quality benchmark datasets, and reproduce state-of-the-art architectures.",
            "Enrolled in B.Tech/M.S./Ph.D. in CS, Data Science, or related quantitative field with strong Python and PyTorch proficiency.",
            "$4,500/month",
            4500,
            "Paid",
            "San Francisco, CA",
            "Hybrid",
            str(today + timedelta(days=2)), # Urgent: 2 days!
            "https://openai.com/careers/internships",
            1
        ),
        (
            2,
            "Full Stack Web Development Intern",
            "Stripe Payments Tech",
            "Web Development",
            "React, TypeScript, Node.js, Python, PostgreSQL, REST APIs",
            "Help architect next-generation checkout experiences and developer dashboards that empower millions of businesses worldwide. Work directly on production code with senior engineers.",
            "Build reusable React components, create REST/GraphQL endpoints, implement automated tests, and collaborate with UX designers.",
            "Pursuing degree in Computer Science or Software Engineering. Hands-on experience with modern JavaScript frameworks.",
            "$3,800/month",
            3800,
            "Paid",
            "Seattle, WA",
            "Remote",
            str(today + timedelta(days=3)), # Approaching: 3 days!
            "https://stripe.com/jobs",
            1
        ),
        (
            3,
            "Python Backend & Cloud Systems Intern",
            "Razorpay Engineering",
            "Python Development",
            "Python, Flask, FastAPI, Docker, Redis, SQL, Git",
            "Build ultra-reliable payment routing engines and microservices handling 10,000+ requests per second. Optimize database queries and caching layers.",
            "Write high-throughput backend services in Python, design RESTful APIs, containerize applications with Docker, and monitor service latency.",
            "Strong grasp of Data Structures, Algorithms, Python OOP, and relational databases. Prior backend projects required.",
            "₹45,000/month",
            45000,
            "Paid",
            "Bangalore, India",
            "Hybrid",
            str(today + timedelta(days=7)),
            "https://razorpay.com/jobs",
            1
        ),
        (
            4,
            "Data Science & Predictive Analytics Intern",
            "Snowflake Cloud Data",
            "Data Science",
            "Python, SQL, Pandas, Scikit-learn, Tableau, Statistics",
            "Analyze petabyte-scale telemetry data to discover product adoption insights, forecast customer churn, and build predictive machine learning models.",
            "Develop ETL pipelines, conduct exploratory data analysis, build scikit-learn models, and build executive dashboards.",
            "Degree in Statistics, CS, Data Science, or Mathematics. Excellent SQL querying and data visualization abilities.",
            "$3,500/month",
            3500,
            "Paid",
            "San Jose, CA",
            "Remote",
            str(today + timedelta(days=12)),
            "https://snowflake.com/careers",
            1
        ),
        (
            5,
            "Java Enterprise Systems Intern",
            "Goldman Sachs Engineering",
            "Java Development",
            "Java, Spring Boot, Microservices, Hibernate, MySQL, Kafka",
            "Develop high-performance financial transaction ledgers, trading system integrations, and enterprise microservices following strict regulatory benchmarks.",
            "Implement enterprise Spring Boot services, optimize concurrency and multithreading code, and build JUnit automated testing suites.",
            "Final/pre-final year engineering student with solid Java fundamentals, Object Oriented Design, and multi-threading concepts.",
            "$4,200/month",
            4200,
            "Paid",
            "New York, NY",
            "Onsite",
            str(today + timedelta(days=5)),
            "https://goldmansachs.com/careers",
            1
        ),
        (
            6,
            "Cloud DevOps & Infrastructure Intern",
            "Datadog Cloud Observability",
            "Cloud Computing",
            "AWS, Docker, Kubernetes, Terraform, Linux, CI/CD, Python",
            "Build and automate planetary-scale cloud infrastructure. Ensure high availability across multi-cloud regions using Infrastructure-as-Code.",
            "Maintain Kubernetes clusters, automate deployment pipelines with GitHub Actions, monitor metric alerts, and write IaC modules in Terraform.",
            "Understanding of Linux OS internals, basic networking (TCP/IP, DNS), Docker containers, and AWS or GCP basics.",
            "$3,600/month",
            3600,
            "Paid",
            "Austin, TX",
            "Remote",
            str(today + timedelta(days=14)),
            "https://datadoghq.com/careers",
            1
        ),
        (
            7,
            "Cybersecurity & Pen-Testing Intern",
            "CrowdStrike Intelligence",
            "Cybersecurity",
            "Network Security, Python, Wireshark, Linux, OWASP Top 10, Penetration Testing",
            "Protect global cloud infrastructure by discovering vulnerabilities, conducting threat simulations, auditing security configurations, and monitoring SIEM logs.",
            "Participate in red/blue team simulations, investigate suspicious network traffic, audit source code for security flaws, and write vulnerability assessment reports.",
            "Knowledge of ethical hacking methodologies, TCP/IP protocols, OWASP guidelines, and command-line Linux.",
            "$3,900/month",
            3900,
            "Paid",
            "Denver, CO",
            "Hybrid",
            str(today + timedelta(days=8)),
            "https://crowdstrike.com/careers",
            1
        ),
        (
            8,
            "UI/UX Product Design Intern",
            "Figma Design Studio",
            "UI/UX Design",
            "Figma, Wireframing, Prototyping, User Research, Design Systems, HTML/CSS",
            "Design delightful user journeys, design systems, and mobile/web interactions for our community of millions of creators. Prototype interactive user interfaces.",
            "Conduct student and professional usability tests, build high-fidelity interactive Figma prototypes, document component design tokens, and iterate on user feedback.",
            "Pursuing degree in Human-Computer Interaction (HCI), Graphic Design, or Digital Media. Compelling online portfolio showing case studies.",
            "$3,400/month",
            3400,
            "Paid",
            "San Francisco, CA",
            "Remote",
            str(today + timedelta(days=6)),
            "https://figma.com/careers",
            1
        ),
        (
            9,
            "Digital Growth Marketing & Content Intern",
            "HubSpot Academy",
            "Digital Marketing",
            "SEO, Content Strategy, Google Analytics, Social Media Marketing, Email Campaigns, Copywriting",
            "Drive organic user acquisition, content strategy, and viral social campaigns. Analyze conversion funnels and run A/B growth experiments.",
            "Optimize blog posts for targeted search queries, manage LinkedIn and Twitter developer campaigns, create drip email nurture funnels, and track ROI in Google Analytics.",
            "Strong communication skills, passionate about storytelling and metrics-driven growth marketing.",
            "$2,200/month",
            2200,
            "Paid",
            "Cambridge, MA",
            "Remote",
            str(today + timedelta(days=10)),
            "https://hubspot.com/jobs",
            1
        ),
        (
            10,
            "Machine Learning Engineer Intern - Computer Vision",
            "NVIDIA Autonomous Vehicles",
            "Machine Learning",
            "Python, C++, PyTorch, OpenCV, Computer Vision, CUDA, Linux",
            "Train deep neural networks for 3D object detection, semantic segmentation, and sensor fusion running on embedded NVIDIA DRIVE platforms.",
            "Benchmark vision transformer models, optimize inference speed with TensorRT, and curate synthetic simulation data.",
            "Strong foundation in deep learning, linear algebra, and image processing. Proficiency with PyTorch and C++.",
            "$4,800/month",
            4800,
            "Paid",
            "Santa Clara, CA",
            "Onsite",
            str(today + timedelta(days=4)),
            "https://nvidia.com/careers",
            1
        ),
        (
            11,
            "NLP & Generative AI Intern",
            "Cohere AI",
            "Artificial Intelligence",
            "Python, Transformers, Hugging Face, LLMs, LangChain, Vector Databases",
            "Build Retrieval Augmented Generation (RAG) applications, fine-tune embedding models, and benchmark prompt safety protocols for enterprise customers.",
            "Fine-tune transformer models on domain datasets, implement semantic search using ChromaDB/Pinecone, and evaluate hallucination rates.",
            "Strong Python skills, hands-on experience fine-tuning Hugging Face models, and understanding of transformer attention mechanisms.",
            "$4,000/month",
            4000,
            "Paid",
            "Toronto, ON",
            "Remote",
            str(today + timedelta(days=18)),
            "https://cohere.com/careers",
            1
        ),
        (
            12,
            "Frontend Engineer Intern (React / Next.js)",
            "Vercel Platforms",
            "Web Development",
            "React, Next.js, TypeScript, Tailwind CSS, Web Vitals, Git",
            "Help deliver instant loading developer tools and dashboard features on the world's most popular React deployment cloud.",
            "Develop server-rendered components with Next.js App Router, optimize Core Web Vitals, and write end-to-end Cypress tests.",
            "Experience building responsive web apps with React and TypeScript. Passion for design systems and fluid animations.",
            "$3,700/month",
            3700,
            "Paid",
            "San Francisco, CA",
            "Remote",
            str(today + timedelta(days=15)),
            "https://vercel.com/careers",
            1
        ),
        (
            13,
            "Data Engineering & Pipeline Intern",
            "Swiggy Analytics",
            "Data Science",
            "Python, SQL, Apache Spark, Airflow, Snowflake, AWS",
            "Build scalable real-time and batch pipelines ingesting millions of food order transactions, delivery routes, and restaurant metrics.",
            "Develop Airflow DAGs, write Spark jobs for feature stores, validate data quality schemas, and optimize SQL warehousing queries.",
            "Proficient in Python and SQL. Familiarity with big data concepts or distributed systems is a plus.",
            "₹50,000/month",
            50000,
            "Paid",
            "Hyderabad, India",
            "Hybrid",
            str(today + timedelta(days=9)),
            "https://swiggy.com/careers",
            1
        ),
        (
            14,
            "Cloud Security & Infrastructure Intern",
            "Cloudflare Edge Network",
            "Cybersecurity",
            "Linux, Go, Python, Network Protocols, TLS/SSL, DDoS Mitigation",
            "Help defend the Internet from multi-terabit DDoS attacks and investigate zero-day security vulnerabilities across 300+ global edge cities.",
            "Analyze anomalous traffic spikes, build telemetry scripts in Go or Python, and test firewall rule engines.",
            "Understanding of TCP/IP, DNS, HTTP/3, and Linux shell scripting. Strong interest in network security.",
            "$4,100/month",
            4100,
            "Paid",
            "Austin, TX",
            "Hybrid",
            str(today + timedelta(days=11)),
            "https://cloudflare.com/careers",
            1
        ),
        (
            15,
            "Python Backend Microservices Intern",
            "Spotify Audio Platform",
            "Python Development",
            "Python, Django, PostgreSQL, Docker, AsyncIO, GraphQL, Git",
            "Contribute to high-throughput audio metadata streaming services, playlist recommendation backends, and podcast creator APIs.",
            "Build asynchronous REST and GraphQL endpoints in Python, optimize database indices, write unit tests, and profile memory consumption.",
            "Strong software design skills in Python, familiarity with relational databases, and curiosity about audio streaming tech.",
            "$3,900/month",
            3900,
            "Paid",
            "New York, NY",
            "Remote",
            str(today + timedelta(days=16)),
            "https://spotify.com/jobs",
            1
        ),
        (
            16,
            "Java Distributed Backend Intern",
            "Oracle Cloud Infrastructure",
            "Java Development",
            "Java, Spring, Distributed Systems, Multithreading, Linux, Docker",
            "Build resilient distributed control planes and storage orchestrators powering mission-critical enterprise workloads globally.",
            "Work on fault-tolerant Java services, implement consensus algorithms, design REST APIs, and profile system bottlenecks.",
            "Excellent Java knowledge (Collections, Concurrency, JVM tuning). Enrolled in CS or related degree.",
            "$4,000/month",
            4000,
            "Paid",
            "Seattle, WA",
            "Onsite",
            str(today + timedelta(days=20)),
            "https://oracle.com/careers",
            1
        ),
        (
            17,
            "Product Designer & UX Researcher Intern",
            "Airbnb Experiences",
            "UI/UX Design",
            "Figma, User Journey Mapping, Rapid Prototyping, Design Systems, Mobile UX",
            "Craft simple, empathetic, and visually captivating mobile interfaces that connect travelers with unique local hosts and experiences.",
            "Interview hosts and guests, map out end-to-end booking journeys, design responsive interfaces, and test micro-interactions.",
            "Design portfolio demonstrating problem-solving, user-centered thinking, and aesthetic polish.",
            "$3,500/month",
            3500,
            "Paid",
            "San Francisco, CA",
            "Hybrid",
            str(today + timedelta(days=22)),
            "https://airbnb.com/careers",
            1
        ),
        (
            18,
            "Site Reliability Engineering (SRE) Intern",
            "GitHub Infrastructure",
            "Cloud Computing",
            "Linux, Kubernetes, Bash, Python, Prometheus, Grafana, Terraform",
            "Ensure 99.99% availability for 100+ million developers. Automate failover processes, enhance monitoring dashboards, and triage incidents.",
            "Develop self-healing automation scripts, improve Grafana dashboards, conduct chaos engineering experiments, and improve release reliability.",
            "Comfortable in a Linux terminal, scripting with Python or Bash, and eager to learn cloud infrastructure reliability.",
            "$4,300/month",
            4300,
            "Paid",
            "Remote",
            "Remote",
            str(today + timedelta(days=13)),
            "https://github.com/careers",
            1
        ),
        (
            19,
            "Performance Marketing & Social Media Intern",
            "Canva Creative Platform",
            "Digital Marketing",
            "Social Media Strategy, Meta Ads, TikTok Trends, Copywriting, Canva, Data Analysis",
            "Engage high-school and college creator communities through viral social campaigns, influencer partnerships, and educational tutorials.",
            "Create engaging social templates, manage campaign calendar, analyze follower growth metrics, and execute influencer outreach.",
            "Creative thinker, avid content consumer/creator on TikTok and Instagram, passionate about design democracy.",
            "$2,400/month",
            2400,
            "Paid",
            "Austin, TX",
            "Remote",
            str(today + timedelta(days=25)),
            "https://canva.com/careers",
            1
        ),
        (
            20,
            "Deep Learning Robotics Perception Intern",
            "Tesla Autopilot Team",
            "Machine Learning",
            "Python, C++, PyTorch, Computer Vision, SLAM, ROS, Linux",
            "Develop state-of-the-art vision models for humanoid robotics perception, spatial depth reasoning, and robotic limb trajectory planning.",
            "Train spatial temporal neural networks, process synthetic simulation datasets, and optimize model latency on custom hardware.",
            "Undergraduate or Graduate student in CS, Robotics, or Electrical Engineering with deep learning coursework.",
            "$4,600/month",
            4600,
            "Paid",
            "Palo Alto, CA",
            "Onsite",
            str(today + timedelta(days=1)), # Urgent: Tomorrow!
            "https://tesla.com/careers",
            1
        ),
        (
            21,
            "Open Source Web Community Intern",
            "Mozilla Foundation",
            "Web Development",
            "JavaScript, HTML5, CSS3, Web Standards, Documentation, Git",
            "Contribute to MDN Web Docs, open web documentation, accessibility audits, and open-source browser developer tooling.",
            "Write interactive web demos, test accessibility compliance, document newly standardized web APIs, and engage with community contributors.",
            "Passionate about the open web, clean semantic HTML, accessibility, and technical documentation.",
            "Unpaid / College Credit + $500 Stipend Grant",
            500,
            "Paid",
            "Remote",
            "Remote",
            str(today + timedelta(days=28)),
            "https://mozilla.org/careers",
            1
        ),
        (
            22,
            "Non-Profit Data & Tech Fellow (Summer)",
            "Code for America",
            "Data Science",
            "Python, SQL, Open Data, Data Visualization, Excel",
            "Help modernize civic public benefits systems, analyze public health access data, and assist municipal governments with transparent reporting.",
            "Clean government open datasets, build interactive community maps and charts, and present insights to civic leaders.",
            "Undergraduate student in public policy, computer science, or data analytics with a heart for public service.",
            "Unpaid (Volunteer / Academic Practicum)",
            0,
            "Unpaid",
            "Chicago, IL",
            "Remote",
            str(today - timedelta(days=2)), # Overdue demo: 2 days ago!
            "https://codeforamerica.org/jobs",
            1
        )
    ]

    for item in internships_data:
        cur.execute("""
            INSERT OR REPLACE INTO internships 
            (id, title, company_name, domain, required_skills, description, responsibilities, eligibility, stipend, stipend_amount, stipend_type, location, work_mode, deadline, application_url, is_active, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        """, (
            item[0], item[1], item[2], item[3], item[4], item[5], item[6], item[7], item[8], item[9], item[10], item[11], item[12], item[13], item[14], item[15]
        ))

    # 3. Seed Sample Applications for Alex Johnson (User ID: 2)
    cur.execute("""
        INSERT OR IGNORE INTO applications 
        (id, user_id, internship_id, company_name, role_title, domain, status, applied_date, interview_date, deadline, application_url, stipend, location, notes)
        VALUES 
        (1, 2, 1, 'OpenAI Research Lab', 'AI & Machine Learning Research Intern', 'Artificial Intelligence', 'Interview Scheduled', ?, ?, ?, 'https://openai.com/careers/internships', '$4,500/month', 'San Francisco, CA', 'Technical interview round scheduled with Dr. Smith. Focus on Transformer architectures and PyTorch implementations.'),
        (2, 2, 4, 'Snowflake Cloud Data', 'Data Science & Predictive Analytics Intern', 'Data Science', 'Shortlisted', ?, NULL, ?, 'https://snowflake.com/careers', '$3,500/month', 'San Jose, CA', 'Passed initial resume screening and online assessment (95% score). Awaiting team match callback.'),
        (3, 2, 2, 'Stripe Payments Tech', 'Full Stack Web Development Intern', 'Web Development', 'Under Review', ?, NULL, ?, 'https://stripe.com/jobs', '$3,800/month', 'Seattle, WA', 'Submitted portfolio highlighting full-stack dashboard project.'),
        (4, 2, 10, 'NVIDIA Autonomous Vehicles', 'Machine Learning Engineer Intern - Computer Vision', 'Machine Learning', 'Applied', ?, NULL, ?, 'https://nvidia.com/careers', '$4,800/month', 'Santa Clara, CA', 'Direct application on university portal. Referenced computer vision paper.'),
        (5, 2, 20, 'Tesla Autopilot Team', 'Deep Learning Robotics Perception Intern', 'Machine Learning', 'Rejected', ?, NULL, ?, 'https://tesla.com/careers', '$4,600/month', 'Palo Alto, CA', 'Applied early. Position filled internally, encouraged to re-apply next cycle.')
    """, (
        str(today - timedelta(days=10)), str(today + timedelta(days=4)), str(today + timedelta(days=2)),
        str(today - timedelta(days=8)), str(today + timedelta(days=12)),
        str(today - timedelta(days=5)), str(today + timedelta(days=3)),
        str(today - timedelta(days=2)), str(today + timedelta(days=4)),
        str(today - timedelta(days=20)), str(today + timedelta(days=1))
    ))

    # 4. Seed Saved Internships for Alex Johnson
    cur.execute("""
        INSERT OR IGNORE INTO saved_internships (user_id, internship_id)
        VALUES (2, 3), (2, 11), (2, 15)
    """)

    # 5. Seed Notifications for Alex Johnson
    cur.execute("""
        INSERT OR IGNORE INTO notifications (id, user_id, title, message, type, is_read, link)
        VALUES 
        (1, 2, 'Urgent Deadline: OpenAI Research Lab', 'Application deadline closes in 2 days! Complete your submission.', 'deadline', 0, '/internships/1'),
        (2, 2, 'Interview Scheduled: OpenAI Research Lab', 'Your technical interview is scheduled for in 4 days. Check your tracker notes for preparation links.', 'interview', 0, '/applications'),
        (3, 2, 'Application Shortlisted: Snowflake Cloud Data', 'Great news! Your application has advanced to the Shortlisted stage.', 'status', 1, '/applications')
    """)

    conn.commit()
    conn.close()
    print("Database initialized and successfully seeded with realistic sample data!")

if __name__ == '__main__':
    seed_database()

