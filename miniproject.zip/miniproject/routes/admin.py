import json
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from routes.auth import admin_required
from models.user import UserModel
from models.internship import InternshipModel
from models.application import ApplicationModel

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin')
@admin_required
def index():
    stats = ApplicationModel.get_platform_stats()
    recent_apps = ApplicationModel.get_recent_all(limit=10)
    internships = InternshipModel.get_all(include_inactive=True)
    students = UserModel.get_all_students()

    # Domain breakdown across platform internships
    domain_counts = {}
    for item in internships:
        d = item['domain']
        domain_counts[d] = domain_counts.get(d, 0) + 1

    chart_domain_labels = list(domain_counts.keys())
    chart_domain_values = list(domain_counts.values())

    return render_template(
        'admin/dashboard.html',
        stats=stats,
        recent_apps=recent_apps,
        total_internships=len(internships),
        total_students=len(students),
        chart_domain_labels=json.dumps(chart_domain_labels),
        chart_domain_values=json.dumps(chart_domain_values)
    )

@admin_bp.route('/admin/internships')
@admin_required
def internships_list():
    all_listings = InternshipModel.get_all(include_inactive=True)
    return render_template('admin/internships.html', internships=all_listings)

@admin_bp.route('/admin/internships/create', methods=['GET', 'POST'])
@admin_required
def create_internship():
    domains = [
        "Artificial Intelligence",
        "Machine Learning",
        "Python Development",
        "Data Science",
        "Web Development",
        "Java Development",
        "Cloud Computing",
        "Cybersecurity",
        "Digital Marketing",
        "UI/UX Design"
    ]

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        company_name = request.form.get('company_name', '').strip()
        domain = request.form.get('domain', '').strip()
        required_skills = request.form.get('required_skills', '').strip()
        description = request.form.get('description', '').strip()
        responsibilities = request.form.get('responsibilities', '').strip()
        eligibility = request.form.get('eligibility', '').strip()
        stipend = request.form.get('stipend', '').strip()
        stipend_amount = request.form.get('stipend_amount', '0').strip()
        stipend_type = request.form.get('stipend_type', 'Paid').strip()
        location = request.form.get('location', '').strip()
        work_mode = request.form.get('work_mode', 'Remote').strip()
        deadline = request.form.get('deadline', '').strip()
        application_url = request.form.get('application_url', '').strip()

        if not title or not company_name or not deadline or not application_url:
            flash("Title, company name, deadline, and application URL are required fields.", "danger")
            return render_template('admin/internship_form.html', domains=domains, item=request.form, is_edit=False)

        try:
            amt = int(stipend_amount) if stipend_amount.isdigit() else 0
            InternshipModel.create(
                title=title,
                company_name=company_name,
                domain=domain,
                required_skills=required_skills,
                description=description,
                responsibilities=responsibilities,
                eligibility=eligibility,
                stipend=stipend,
                stipend_amount=amt,
                stipend_type=stipend_type,
                location=location,
                work_mode=work_mode,
                deadline=deadline,
                application_url=application_url,
                created_by=session['user_id']
            )
            flash(f"Internship listing '{title}' created successfully!", "success")
            return redirect(url_for('admin.internships_list'))
        except Exception as e:
            flash(f"Error creating listing: {str(e)}", "danger")

    return render_template('admin/internship_form.html', domains=domains, item={}, is_edit=False)

@admin_bp.route('/admin/internships/<int:id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_internship(id):
    item = InternshipModel.get_by_id(id)
    if not item:
        flash("Internship not found.", "danger")
        return redirect(url_for('admin.internships_list'))

    domains = [
        "Artificial Intelligence",
        "Machine Learning",
        "Python Development",
        "Data Science",
        "Web Development",
        "Java Development",
        "Cloud Computing",
        "Cybersecurity",
        "Digital Marketing",
        "UI/UX Design"
    ]

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        company_name = request.form.get('company_name', '').strip()
        domain = request.form.get('domain', '').strip()
        required_skills = request.form.get('required_skills', '').strip()
        description = request.form.get('description', '').strip()
        responsibilities = request.form.get('responsibilities', '').strip()
        eligibility = request.form.get('eligibility', '').strip()
        stipend = request.form.get('stipend', '').strip()
        stipend_amount = request.form.get('stipend_amount', '0').strip()
        stipend_type = request.form.get('stipend_type', 'Paid').strip()
        location = request.form.get('location', '').strip()
        work_mode = request.form.get('work_mode', 'Remote').strip()
        deadline = request.form.get('deadline', '').strip()
        application_url = request.form.get('application_url', '').strip()
        is_active = True if request.form.get('is_active') == '1' else False

        amt = int(stipend_amount) if stipend_amount.isdigit() else 0
        InternshipModel.update(
            internship_id=id,
            title=title,
            company_name=company_name,
            domain=domain,
            required_skills=required_skills,
            description=description,
            responsibilities=responsibilities,
            eligibility=eligibility,
            stipend=stipend,
            stipend_amount=amt,
            stipend_type=stipend_type,
            location=location,
            work_mode=work_mode,
            deadline=deadline,
            application_url=application_url,
            is_active=is_active
        )
        flash("Internship listing updated successfully!", "success")
        return redirect(url_for('admin.internships_list'))

    return render_template('admin/internship_form.html', domains=domains, item=item, is_edit=True)

@admin_bp.route('/admin/internships/<int:id>/toggle', methods=['POST'])
@admin_required
def toggle_internship(id):
    InternshipModel.toggle_status(id)
    flash("Internship visibility status updated.", "info")
    return redirect(url_for('admin.internships_list'))

@admin_bp.route('/admin/internships/<int:id>/delete', methods=['POST'])
@admin_required
def delete_internship(id):
    InternshipModel.delete(id)
    flash("Internship listing permanently deleted.", "warning")
    return redirect(url_for('admin.internships_list'))

@admin_bp.route('/admin/students')
@admin_required
def students_list():
    students = UserModel.get_all_students()
    return render_template('admin/students.html', students=students)

